import type { FieldErrors, UseFormRegister } from 'react-hook-form';
import { Input, Label, FieldError, Select, Textarea } from '@/components/ui/input';
import type { PersonalInfoValues } from '@/lib/schemas/personal-info';

export function PersonalInfoFields<T extends PersonalInfoValues>({
  register,
  errors,
}: {
  register: UseFormRegister<T>;
  errors: FieldErrors<T>;
}) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <Label htmlFor="fullName">Full name</Label>
        <Input id="fullName" {...register('fullName' as any)} />
        <FieldError message={errors.fullName?.message as string | undefined} />
      </div>

      <div className="sm:col-span-2">
        <Label htmlFor="permanentAddress">Permanent address</Label>
        <Textarea id="permanentAddress" rows={2} {...register('permanentAddress' as any)} />
        <FieldError message={errors.permanentAddress?.message as string | undefined} />
      </div>

      <div>
        <Label htmlFor="nic">NIC</Label>
        <Input id="nic" {...register('nic' as any)} />
      </div>
      <div>
        <Label htmlFor="passportNumber">Passport number</Label>
        <Input id="passportNumber" {...register('passportNumber' as any)} />
      </div>

      <div>
        <Label htmlFor="dateOfBirth">Date of birth</Label>
        <Input id="dateOfBirth" type="date" {...register('dateOfBirth' as any)} />
        <FieldError message={errors.dateOfBirth?.message as string | undefined} />
      </div>
      <div>
        <Label htmlFor="gender">Gender</Label>
        <Select id="gender" {...register('gender' as any)}>
          <option value="">Select</option>
          <option value="MALE">Male</option>
          <option value="FEMALE">Female</option>
          <option value="OTHER">Other</option>
        </Select>
        <FieldError message={errors.gender?.message as string | undefined} />
      </div>

      <div>
        <Label htmlFor="civilStatus">Civil status</Label>
        <Select id="civilStatus" {...register('civilStatus' as any)}>
          <option value="">Select</option>
          <option value="SINGLE">Single</option>
          <option value="MARRIED">Married</option>
          <option value="DIVORCED">Divorced</option>
          <option value="WIDOWED">Widowed</option>
          <option value="OTHER">Other</option>
        </Select>
        <FieldError message={errors.civilStatus?.message as string | undefined} />
      </div>
      <div />

      <div>
        <Label htmlFor="heightCm">Height (cm)</Label>
        <Input id="heightCm" type="number" {...register('heightCm' as any)} />
      </div>
      <div>
        <Label htmlFor="weightKg">Weight (kg)</Label>
        <Input id="weightKg" type="number" {...register('weightKg' as any)} />
      </div>

      <div>
        <Label htmlFor="primaryPhone">Primary phone</Label>
        <Input id="primaryPhone" {...register('primaryPhone' as any)} />
        <FieldError message={errors.primaryPhone?.message as string | undefined} />
      </div>
      <div>
        <Label htmlFor="secondaryPhone">Secondary phone</Label>
        <Input id="secondaryPhone" {...register('secondaryPhone' as any)} />
      </div>

      <div>
        <Label htmlFor="emergencyContactName">Emergency contact name</Label>
        <Input id="emergencyContactName" {...register('emergencyContactName' as any)} />
        <FieldError message={errors.emergencyContactName?.message as string | undefined} />
      </div>
      <div>
        <Label htmlFor="emergencyContactNumber">Emergency contact number</Label>
        <Input id="emergencyContactNumber" {...register('emergencyContactNumber' as any)} />
        <FieldError message={errors.emergencyContactNumber?.message as string | undefined} />
      </div>
      <div>
        <Label htmlFor="emergencyContactRelationship">Relationship</Label>
        <Input id="emergencyContactRelationship" {...register('emergencyContactRelationship' as any)} />
        <FieldError message={errors.emergencyContactRelationship?.message as string | undefined} />
      </div>
      <div />

      <div>
        <Label htmlFor="policeDivision">Police division</Label>
        <Input id="policeDivision" {...register('policeDivision' as any)} />
      </div>
      <div>
        <Label htmlFor="policeStation">Police station</Label>
        <Input id="policeStation" {...register('policeStation' as any)} />
      </div>
    </div>
  );
}
