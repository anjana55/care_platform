'use client';

import { useRouter } from 'next/navigation';
import { CheckCircle2 } from 'lucide-react';
import { useCaregiver, useUpdateCaregiverStatus } from '@/lib/hooks/use-caregivers';
import { Button } from '@/components/ui/button';
import { useTranslation } from '@/lib/i18n/provider';

export function ReviewStep({ caregiverId, onBack }: { caregiverId: string; onBack: () => void }) {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: caregiver } = useCaregiver(caregiverId);
  const updateStatus = useUpdateCaregiverStatus(caregiverId);

  if (updateStatus.isSuccess) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <CheckCircle2 size={40} className="text-brand" />
        <h3 className="text-lg font-semibold text-ink">{t('caregivers.wizard.finishedTitle')}</h3>
        <p className="max-w-sm text-sm text-ink/60">{t('caregivers.wizard.finishedBody')}</p>
        <Button className="mt-2" onClick={() => router.push(`/caregivers/${caregiverId}`)}>
          View caregiver profile
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {caregiver && (
        <div className="grid grid-cols-1 gap-4 rounded border border-border p-4 sm:grid-cols-2">
          <div>
            <div className="text-xs text-ink/50">Full name</div>
            <div className="text-sm text-ink">{caregiver.fullName}</div>
          </div>
          <div>
            <div className="text-xs text-ink/50">Registration number</div>
            <div className="text-sm text-ink">{caregiver.registrationNumber}</div>
          </div>
          <div>
            <div className="text-xs text-ink/50">Phone</div>
            <div className="text-sm text-ink">{caregiver.primaryPhone}</div>
          </div>
          <div>
            <div className="text-xs text-ink/50">Skills</div>
            <div className="text-sm text-ink">{caregiver.skills.map((s) => s.name).join(', ') || '—'}</div>
          </div>
          <div>
            <div className="text-xs text-ink/50">Languages</div>
            <div className="text-sm text-ink">{caregiver.languages.map((l) => l.name).join(', ') || '—'}</div>
          </div>
          <div>
            <div className="text-xs text-ink/50">Documents</div>
            <div className="text-sm text-ink">{caregiver.documents.length} uploaded</div>
          </div>
        </div>
      )}

      <p className="text-sm text-ink/60">
        Submitting will move this caregiver from <strong>Draft</strong> to <strong>Registered</strong>, ready for document
        verification.
      </p>

      {updateStatus.isError && <p className="text-sm text-danger">Could not submit. Please try again.</p>}

      <div className="flex justify-between border-t border-border pt-4">
        <Button type="button" variant="secondary" onClick={onBack}>
          {t('caregivers.wizard.back')}
        </Button>
        <Button type="button" onClick={() => updateStatus.mutate('REGISTERED')} disabled={updateStatus.isPending}>
          {updateStatus.isPending ? t('common.loading') : t('caregivers.wizard.finish')}
        </Button>
      </div>
    </div>
  );
}
