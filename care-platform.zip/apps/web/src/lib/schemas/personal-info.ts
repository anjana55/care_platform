import { z } from 'zod';

export const personalInfoSchema = z.object({
  fullName: z.string().min(2, 'Full name is required'),
  permanentAddress: z.string().min(5, 'Address is required'),
  nic: z.string().optional(),
  passportNumber: z.string().optional(),
  dateOfBirth: z.string().min(1, 'Date of birth is required'),
  gender: z.enum(['MALE', 'FEMALE', 'OTHER']),
  civilStatus: z.enum(['SINGLE', 'MARRIED', 'DIVORCED', 'WIDOWED', 'OTHER']),
  heightCm: z.coerce.number().optional(),
  weightKg: z.coerce.number().optional(),
  primaryPhone: z.string().min(9, 'A valid phone number is required'),
  secondaryPhone: z.string().optional(),
  emergencyContactName: z.string().min(2, 'Required'),
  emergencyContactNumber: z.string().min(9, 'Required'),
  emergencyContactRelationship: z.string().min(2, 'Required'),
  policeDivision: z.string().optional(),
  policeStation: z.string().optional(),
});

export type PersonalInfoValues = z.infer<typeof personalInfoSchema>;
