'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import type {
  CaregiverDetail,
  CaregiverListResponse,
  CaregiverSearchFilters,
  DashboardStats,
  Skill,
  Language,
  Location,
} from '../api/types';

export function useDashboardStats() {
  return useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardStats>('/caregivers/dashboard'),
  });
}

function buildCaregiverQuery(filters: CaregiverSearchFilters): string {
  const query = new URLSearchParams();
  if (filters.search) query.set('search', filters.search);
  if (filters.status) query.set('status', filters.status);
  if (filters.gender) query.set('gender', filters.gender);
  if (filters.skillIds?.length) query.set('skillIds', filters.skillIds.join(','));
  if (filters.languageIds?.length) query.set('languageIds', filters.languageIds.join(','));
  if (filters.locationIds?.length) query.set('locationIds', filters.locationIds.join(','));
  if (filters.dayDuty) query.set('dayDuty', 'true');
  if (filters.nightDuty) query.set('nightDuty', 'true');
  if (filters.liveIn24h) query.set('liveIn24h', 'true');
  query.set('page', String(filters.page ?? 1));
  query.set('pageSize', String(filters.pageSize ?? 20));
  return query.toString();
}

export function useCaregivers(filters: CaregiverSearchFilters) {
  return useQuery({
    queryKey: ['caregivers', filters],
    queryFn: () => api.get<CaregiverListResponse>(`/caregivers?${buildCaregiverQuery(filters)}`),
  });
}

export function useCaregiver(id: string | undefined) {
  return useQuery({
    queryKey: ['caregiver', id],
    queryFn: () => api.get<CaregiverDetail>(`/caregivers/${id}`),
    enabled: Boolean(id),
  });
}

export function useSkills() {
  return useQuery({ queryKey: ['skills'], queryFn: () => api.get<Skill[]>('/skills') });
}

export function useLanguages() {
  return useQuery({ queryKey: ['languages'], queryFn: () => api.get<Language[]>('/languages') });
}

export function useLocations() {
  return useQuery({ queryKey: ['locations'], queryFn: () => api.get<Location[]>('/locations') });
}

export function useInvalidateCaregiver(id: string | undefined) {
  const queryClient = useQueryClient();
  return () => {
    queryClient.invalidateQueries({ queryKey: ['caregiver', id] });
    queryClient.invalidateQueries({ queryKey: ['caregivers'] });
    queryClient.invalidateQueries({ queryKey: ['dashboard'] });
  };
}

export function useCreateCaregiver() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (data: Record<string, unknown>) => api.post<CaregiverDetail>('/caregivers', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['caregivers'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
    },
  });
}

export function useUpdateCaregiverStatus(id: string) {
  const invalidate = useInvalidateCaregiver(id);
  return useMutation({
    mutationFn: (status: string) => api.patch<CaregiverDetail>(`/caregivers/${id}/status`, { status }),
    onSuccess: invalidate,
  });
}
