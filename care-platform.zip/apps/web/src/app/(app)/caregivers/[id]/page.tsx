'use client';

import { useParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api/client';
import { useCaregiver, useUpdateCaregiverStatus } from '@/lib/hooks/use-caregivers';
import { useAuth } from '@/lib/api/auth-context';
import { useTranslation } from '@/lib/i18n/provider';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { StatusBadge, VerificationBadge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CAREGIVER_STATUS_OPTIONS, allowedNextStatuses } from '@/lib/caregiver-status';
import { Select } from '@/components/ui/input';

function Field({ label, value }: { label: string; value: string | number | null | undefined }) {
  return (
    <div>
      <div className="text-xs text-ink/50">{label}</div>
      <div className="text-sm text-ink">{value ?? '—'}</div>
    </div>
  );
}

export default function CaregiverProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { t } = useTranslation();
  const { user } = useAuth();
  const { data: caregiver, isLoading } = useCaregiver(id);
  const updateStatus = useUpdateCaregiverStatus(id);

  const { data: references } = useQuery({
    queryKey: ['references', id],
    queryFn: () => api.get<any[]>(`/caregivers/${id}/references`),
    enabled: Boolean(id),
  });
  const { data: verifications } = useQuery({
    queryKey: ['verifications', id],
    queryFn: () => api.get<any[]>(`/caregivers/${id}/verifications`),
    enabled: Boolean(id),
  });
  const { data: auditEntries } = useQuery({
    queryKey: ['audit', id],
    queryFn: () => api.get<any[]>(`/audit-logs?entityType=Caregiver&entityId=${id}`),
    enabled: Boolean(id) && (user?.role === 'ADMIN'),
  });
  const canSeeHealth = user?.role === 'ADMIN' || user?.role === 'VERIFIER';
  const { data: healthInfo } = useQuery({
    queryKey: ['health-information', id],
    queryFn: () => api.get<any>(`/caregivers/${id}/health-information`),
    enabled: Boolean(id) && canSeeHealth,
  });

  if (isLoading || !caregiver) return <p className="text-sm text-ink/50">{t('common.loading')}</p>;

  const nextStatuses = allowedNextStatuses(caregiver.status);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-xl font-semibold text-ink">{caregiver.fullName}</h1>
          <p className="text-sm text-ink/50">{caregiver.registrationNumber}</p>
        </div>
        <div className="flex items-center gap-3">
          <StatusBadge status={caregiver.status} label={t(`caregivers.status.${caregiver.status}`)} />
          {nextStatuses.length > 0 && (user?.role === 'ADMIN' || user?.role === 'VERIFIER') && (
            <Select
              className="w-52"
              value=""
              onChange={(e) => e.target.value && updateStatus.mutate(e.target.value)}
            >
              <option value="">Move to…</option>
              {nextStatuses.map((s) => (
                <option key={s} value={s}>
                  {t(`caregivers.status.${s}`)}
                </option>
              ))}
            </Select>
          )}
        </div>
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">{t('caregivers.profile.tabs.overview')}</TabsTrigger>
          <TabsTrigger value="qualifications">{t('caregivers.profile.tabs.qualifications')}</TabsTrigger>
          <TabsTrigger value="documents">{t('caregivers.profile.tabs.documents')}</TabsTrigger>
          <TabsTrigger value="references">{t('caregivers.profile.tabs.references')}</TabsTrigger>
          <TabsTrigger value="verification">{t('caregivers.profile.tabs.verification')}</TabsTrigger>
          {canSeeHealth && <TabsTrigger value="restricted">{t('caregivers.profile.tabs.restricted')}</TabsTrigger>}
          {user?.role === 'ADMIN' && <TabsTrigger value="audit">{t('caregivers.profile.tabs.audit')}</TabsTrigger>}
        </TabsList>

        <TabsContent value="overview">
          <Card>
            <CardContent className="grid grid-cols-1 gap-5 py-5 sm:grid-cols-3">
              <Field label="NIC" value={caregiver.nic} />
              <Field label="Passport" value={caregiver.passportNumber} />
              <Field label="Date of birth" value={caregiver.dateOfBirth?.slice(0, 10)} />
              <Field label="Gender" value={caregiver.gender} />
              <Field label="Civil status" value={caregiver.civilStatus} />
              <Field label="Height / weight" value={`${caregiver.heightCm ?? '—'} cm / ${caregiver.weightKg ?? '—'} kg`} />
              <Field label="Primary phone" value={caregiver.primaryPhone} />
              <Field label="Secondary phone" value={caregiver.secondaryPhone} />
              <Field label="Address" value={caregiver.permanentAddress} />
              <Field label="Emergency contact" value={`${caregiver.emergencyContactName} (${caregiver.emergencyContactRelationship})`} />
              <Field label="Emergency number" value={caregiver.emergencyContactNumber} />
              <Field label="Police division / station" value={`${caregiver.policeDivision ?? '—'} / ${caregiver.policeStation ?? '—'}`} />
            </CardContent>
          </Card>

          <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
            <Card>
              <CardContent className="py-5">
                <h4 className="mb-3 text-sm font-semibold text-ink">{t('caregivers.profile.tabs.skills')}</h4>
                <div className="flex flex-wrap gap-2">
                  {caregiver.skills.map((s) => (
                    <span key={s.skillId} className="rounded bg-brand-light px-2 py-1 text-xs text-brand-dark">
                      {s.name} · {s.proficiency}
                    </span>
                  ))}
                  {caregiver.skills.length === 0 && <span className="text-sm text-ink/40">None recorded</span>}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-5">
                <h4 className="mb-3 text-sm font-semibold text-ink">{t('caregivers.profile.tabs.languages')}</h4>
                <div className="flex flex-wrap gap-2">
                  {caregiver.languages.map((l) => (
                    <span key={l.languageId} className="rounded bg-accent-light px-2 py-1 text-xs text-accent">
                      {l.name} · {l.proficiency}
                    </span>
                  ))}
                  {caregiver.languages.length === 0 && <span className="text-sm text-ink/40">None recorded</span>}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="qualifications">
          <Card>
            <CardContent className="py-5">
              <p className="text-sm text-ink/50">
                {caregiver.documents.length} document(s) on file. Detailed qualification editing is available from the
                registration wizard steps.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents">
          <Card>
            <CardContent className="divide-y divide-border py-0">
              {caregiver.documents.map((d) => (
                <div key={d.id} className="flex items-center justify-between py-3 first:pt-5 last:pb-5">
                  <div>
                    <div className="text-sm text-ink">{d.documentType.replace('_', ' ')}</div>
                    <div className="text-xs text-ink/50">{d.originalFilename}</div>
                  </div>
                  <VerificationBadge status={d.verificationStatus} />
                </div>
              ))}
              {caregiver.documents.length === 0 && <p className="py-5 text-sm text-ink/40">No documents uploaded.</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="references">
          <Card>
            <CardContent className="divide-y divide-border py-0">
              {references?.map((r) => (
                <div key={r.id} className="flex items-center justify-between py-3 first:pt-5 last:pb-5">
                  <div>
                    <div className="text-sm text-ink">
                      {r.name} <span className="text-ink/40">· {r.relationship}</span>
                    </div>
                    <div className="text-xs text-ink/50">{r.phone}</div>
                  </div>
                  <VerificationBadge status={r.verificationStatus} />
                </div>
              ))}
              {references?.length === 0 && <p className="py-5 text-sm text-ink/40">No references on file.</p>}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="verification">
          <Card>
            <CardContent className="divide-y divide-border py-0">
              {verifications?.map((v) => (
                <div key={v.id} className="flex items-center justify-between py-3 first:pt-5 last:pb-5">
                  <div className="text-sm text-ink">{v.verificationType.replace('_', ' ')}</div>
                  <VerificationBadge status={v.status} />
                </div>
              ))}
              {verifications?.length === 0 && <p className="py-5 text-sm text-ink/40">No verification records yet.</p>}
            </CardContent>
          </Card>
        </TabsContent>

        {canSeeHealth && (
          <TabsContent value="restricted">
            <Card>
              <CardContent className="grid grid-cols-1 gap-5 py-5 sm:grid-cols-2">
                <Field label="Diabetes" value={healthInfo?.hasDiabetes ? t('common.yes') : t('common.no')} />
                <Field label="High blood pressure" value={healthInfo?.hasHighBloodPressure ? t('common.yes') : t('common.no')} />
                <Field
                  label="Able to physically lift patients"
                  value={healthInfo?.physicalAbilityToLiftPatients ? t('common.yes') : t('common.no')}
                />
                <Field label="Surgical history" value={healthInfo?.surgicalHistory} />
                <Field label="Mental health notes" value={healthInfo?.mentalHealthInformation} />
                <Field label="Other notes" value={healthInfo?.otherNotes} />
              </CardContent>
            </Card>
            <p className="mt-3 text-xs text-ink/40">Access to this tab is restricted and every view is recorded in the audit log.</p>
          </TabsContent>
        )}

        {user?.role === 'ADMIN' && (
          <TabsContent value="audit">
            <Card>
              <CardContent className="divide-y divide-border py-0">
                {auditEntries?.map((a: any) => (
                  <div key={a.id} className="flex items-center justify-between py-3 first:pt-5 last:pb-5 text-sm">
                    <span className="text-ink">{a.action.replace(/_/g, ' ')}</span>
                    <span className="text-ink/40">{new Date(a.createdAt).toLocaleString()}</span>
                  </div>
                ))}
                {auditEntries?.length === 0 && <p className="py-5 text-sm text-ink/40">No audit entries yet.</p>}
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
