import 'dotenv/config';
import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { eq, isNull } from 'drizzle-orm';
import { randomUUID as uuid } from 'crypto';
import { caregivers } from '../schema';

/**
 * Run this ONCE, after migration 0003 (which adds `caregivers.public_id` as
 * a nullable column) and BEFORE migration 0004 (which makes it NOT NULL).
 *
 *   npm run db:migrate            # applies 0000-0003
 *   npx tsx src/database/scripts/backfill-public-ids.ts
 *   npm run db:migrate            # applies 0004
 *
 * Safe to re-run: only touches rows where public_id is still null. On a
 * fresh database (no pre-existing caregivers) this is a no-op - new rows
 * already get a public_id at creation time (see caregivers.service.ts /
 * auth.service.ts), so this script exists purely to backfill rows that
 * predate this feature.
 */
async function main() {
  const connection = await mysql.createConnection(
    process.env.DATABASE_URL || 'mysql://care_app:care_app_password@localhost:3306/care_platform',
  );
  const db = drizzle(connection);

  const rows = await db.select({ id: caregivers.id }).from(caregivers).where(isNull(caregivers.publicId));

  console.log(`Backfilling public_id for ${rows.length} caregiver row(s)...`);
  for (const row of rows) {
    await db.update(caregivers).set({ publicId: uuid() }).where(eq(caregivers.id, row.id));
  }
  console.log('Done.');
  await connection.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
