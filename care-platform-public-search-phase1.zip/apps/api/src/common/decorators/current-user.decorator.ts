import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface AuthenticatedUser {
  userId: string;
  email: string;
  role: 'ADMIN' | 'STAFF' | 'VERIFIER' | 'CAREGIVER';
  /** Present only when role === 'CAREGIVER': the caregiver record this login owns. */
  caregiverId?: string;
}

export const CurrentUser = createParamDecorator((_data: unknown, ctx: ExecutionContext): AuthenticatedUser => {
  const request = ctx.switchToHttp().getRequest();
  return request.user;
});
