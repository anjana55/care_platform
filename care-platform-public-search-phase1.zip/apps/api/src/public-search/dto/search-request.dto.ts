import { ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNumber,
  IsOptional,
  IsString,
  IsUUID,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { genderEnum } from '../../database/schema/caregivers.schema';
import { shiftPreferenceEnum } from '../../database/schema/availability.schema';

export const genderPreferenceEnum = ['MALE', 'FEMALE', 'ANY'] as const;

/**
 * Everything here is optional except paging defaults - this is deliberately
 * a "guardian fills in whatever they know" shape, not a set of required
 * hard filters. Which of these become hard filters vs. ranking signals is
 * decided in PublicSearchService, not here (see the architecture: only
 * status + mandatory skills are hard filters; gender/budget/optional skills
 * influence ranking only).
 */
class PatientInfoDto {
  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(120)
  age?: number;

  @ApiPropertyOptional({ enum: ['MALE', 'FEMALE'] })
  @IsOptional()
  @IsEnum(['MALE', 'FEMALE'])
  gender?: 'MALE' | 'FEMALE';

  @ApiPropertyOptional({ type: [String], description: 'Free-text medical conditions, optional' })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  @MaxLength(80, { each: true })
  medicalConditions?: string[];
}

class LocationDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(100)
  district?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(100)
  city?: string;
}

class BudgetDto {
  @ApiPropertyOptional({ description: 'Daily rate ceiling. Influences ranking only - never a hard filter.' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  dailyRate?: number;

  @ApiPropertyOptional({ description: 'Monthly rate ceiling. Influences ranking only - never a hard filter.' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(0)
  monthlyRate?: number;
}

export class SearchRequestDto {
  @ApiPropertyOptional({ type: PatientInfoDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => PatientInfoDto)
  patient?: PatientInfoDto;

  @ApiPropertyOptional({ type: LocationDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => LocationDto)
  location?: LocationDto;

  @ApiPropertyOptional({ enum: genderPreferenceEnum, description: 'Preference, not a hard filter unless ANY is omitted entirely by the caller choosing not to send it' })
  @IsOptional()
  @IsEnum(genderPreferenceEnum)
  caregiverGenderPreference?: (typeof genderPreferenceEnum)[number];

  @ApiPropertyOptional({ type: [String], description: 'Skill IDs the caregiver MUST have (hard filter)' })
  @IsOptional()
  @IsArray()
  @IsUUID('4', { each: true })
  mandatorySkillIds?: string[];

  @ApiPropertyOptional({ type: [String], description: 'Skill IDs that influence ranking only' })
  @IsOptional()
  @IsArray()
  @IsUUID('4', { each: true })
  optionalSkillIds?: string[];

  @ApiPropertyOptional({ type: [String] })
  @IsOptional()
  @IsArray()
  @IsUUID('4', { each: true })
  languageIds?: string[];

  @ApiPropertyOptional({ enum: shiftPreferenceEnum })
  @IsOptional()
  @IsEnum(shiftPreferenceEnum)
  shift?: (typeof shiftPreferenceEnum)[number];

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  desiredStartDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  @Max(50)
  minimumExperienceYears?: number;

  @ApiPropertyOptional({ type: BudgetDto })
  @IsOptional()
  @ValidateNested()
  @Type(() => BudgetDto)
  budget?: BudgetDto;

  @ApiPropertyOptional({ default: 1 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(1000)
  page: number = 1;

  // Deliberately capped well below the staff-side page size ceiling - see
  // architecture P (pagination hard cap / enumeration protection).
  @ApiPropertyOptional({ default: 20 })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(50)
  pageSize: number = 20;
}

export { genderEnum };
